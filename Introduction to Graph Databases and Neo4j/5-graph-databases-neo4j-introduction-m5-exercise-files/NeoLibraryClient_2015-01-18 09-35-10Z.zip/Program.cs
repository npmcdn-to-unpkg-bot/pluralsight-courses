﻿using System;
using Neo4jClient;

namespace NeoLibraryClient
{
    class Program
    {
        static void Main(string[] args)
        {
            var client = new GraphClient(new Uri("http://localhost:7474/db/data"));
            client.Connect();

            var query = client
                .Cypher
                .Match("(a:Actor)")
                .Return(a => a.As<Actor>())
                .Limit(100);

            foreach (var actor in query.Results)
                Console.WriteLine("Name: {0} Wikipedia: {1} Salary:{2}"
                    , actor.name, actor.wikipedia, actor.salary);
            Console.ReadKey();
        }
    }
}
