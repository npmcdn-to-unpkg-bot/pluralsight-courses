﻿using System.Collections.Generic;

namespace NeoHttpClient
{
    public class Statement
    {
        public string statement { get; set; }
    }

    public class NeoStatementRequest
    {
        public NeoStatementRequest(params string[] statements)
        {
            this.statements = new List<Statement>();
            foreach (var statement in statements)
                this.statements.Add(new Statement{statement = statement});
        }
        public List<Statement> statements { get; set; }
    }
}
