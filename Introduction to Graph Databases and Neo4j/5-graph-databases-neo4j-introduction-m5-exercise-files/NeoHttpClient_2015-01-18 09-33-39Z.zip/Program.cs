﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace NeoHttpClient
{
    class Program
    {
        static void Main(string[] args)
        {
            var response = ExecuteCypherStatement("match (a:Actor) return a limit 100")
                .Result;
            foreach (var result in response.results)
            {
                foreach (var data in result.data)
                {
                    foreach (var column in data.row)
                    Console.WriteLine(column.ToString());
                }
            }
            Console.ReadKey();
        }

        async static Task<NeoRowResponse> ExecuteCypherStatement(string statement)
        {
            var httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Accept
                .Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var neoStatement = new NeoStatementRequest(statement);

            var response = await httpClient
                .PostAsync(new Uri("http://localhost:7474/db/data/transaction/commit"), 
                new StringContent(JsonConvert.SerializeObject(neoStatement), 
                    Encoding.UTF8, "application/json"));
            response.EnsureSuccessStatusCode();
            return JsonConvert.DeserializeObject<NeoRowResponse>
                (await response.Content.ReadAsStringAsync());
        }
    }
}
