﻿using System.Collections.Generic;

namespace NeoHttpClient
{
    public class Row
    {
        public string name { get; set; }
        public string wikipedia { get; set; }
        public int? salary { get; set; }

        public override string ToString()
        {
            return string.Format("Name: {0}, Wikipedia: {1}, Salary: {2}", name, wikipedia, salary);
        }
    }

    public class Record
    {
        public IList<Row> row { get; set; }
    }

    public class Result
    {
        public IList<string> columns { get; set; }
        public IList<Record> data { get; set; }
    }

    public class NeoRowResponse
    {
        public IList<Result> results { get; set; }
        public IList<object> errors { get; set; }
    }
}
